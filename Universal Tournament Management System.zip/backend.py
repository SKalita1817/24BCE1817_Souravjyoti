import MongoCRUD as crud
from datetime import datetime, timezone
from contextlib import asynccontextmanager  
#logger setup
import logging
logging.basicConfig(level=logging.INFO,filename="backend.log",filemode="w",format="%(levelname)s | %(name)s\n%(message)s")
logger = logging.getLogger(__name__)

from fastapi import FastAPI,Path, Body, Query, HTTPException
from pydantic import BaseModel, field_validator, Field
from typing import Dict, Any, Annotated

@asynccontextmanager
async def MongoDB_lifespan(app: FastAPI):
    # Startup code
    ok = crud.establishDB()
    if ok:
        logger.info("Successfully connected to MongoDB")
        print("Successfully connected to MongoDB")
    else:
        print("CRITICAL")
        logger.critical("Unable to connect to MongoDB!",stack_info=True)
        print("Please Restart server!")

    yield

    # Shutdown code
    crud.disconnectDB()
    logger.info("Disconnected from MongoDB")

app = FastAPI(lifespan=MongoDB_lifespan)

#-----------Player---------------------------
class player_model(BaseModel):
    player_name: str
    gender: str
    contact: Dict[str,Any]
    age: int | None = None
    dob: datetime | None

    @field_validator("gender",mode="after")
    @classmethod
    def validate_gender(cls, value:str):
        if value not in ("M", "F"):
            raise ValueError("gender must be in 'M' or 'F'")
        return value

@app.post("/player")
async def create_player(player: player_model):
    logger.debug(player.model_dump_json())
    return crud.create_player(player.model_dump())

@app.post("/player/query")
async def get_player_by_query(query: dict = Body(...,description="Query info in MongoDB query format")):
    return crud.get_players_by_query(query)

@app.get("/player/search")
async def search_players_by_name(name: Annotated[str, Query(..., min_length=1, description="Player name or partial name to search, case-insensitive")]):
    return crud.get_players_by_name(name)
@app.get("/player/all")
async def get_all_players():
    return crud.get_players_by_query({})

@app.get("/player/{_id}")
async def get_player(_id: str = Path(description="_id of the player to find, must be in the form P1234",max_length=5, pattern=r"^P\d{4}$")):
    return crud.get_player(_id)

@app.patch("/player/{_id}")
async def update_player(_id: str = Path(description="_id of the player to update, must be in the form P1234",max_length=5, pattern=r"^P\d{4}$"), 
                        fields: dict = Body(...,description="fields and the value to update to")):
    if fields.get("gender","M") not in ("M","F"):
        return {"ValueError":"Gender cannot be changed to anything except M or F"}
    
    return crud.update_player(_id, fields)

@app.delete("/player/{_id}")
async def delete_player(_id: str = Path(description="_id of the player to update, must be in the form P1234",max_length=5, pattern=r"^P\d{4}$")):
    return crud.delete_player(_id)

#---------Team-------------------------------------

class team_model(BaseModel):
    team_name: str
    sport: str
    members: list[Dict[str, Any]]

@app.post("/team")
async def create_team(team: team_model):
    return crud.create_team(team.model_dump())

@app.post("/team/query")
async def get_team(query: dict = Body(...,description="Query info in MongoDB query format")):
    return crud.get_teams_by_query(query)

@app.get("/team/search")
async def search_teams_by_name(name: Annotated[str, Query(..., min_length=1, description="Team name or partial name to search, case-insensitive")]):
    return crud.get_teams_by_name(name)

@app.get("/team/all")
async def get_all_teams():
    return crud.get_teams_by_query({})

@app.get("/team/{_id}")
async def get_team_by_id(_id: str = Path(description="_id of the team to find, must be in the form T1234",max_length=5, pattern=r"^T\d{4}$")):
    return crud.get_team(_id)

@app.patch("/team/{_id}")
async def update_team(_id: str = Path(description="_id of the team to update, must be in the form T1234",max_length=5, pattern=r"^T\d{4}$"),
                      fields: dict = Body(...,description="fields and the value to update to")):
    return crud.update_team(_id, fields)

@app.delete("/team/{_id}")
async def delete_team(_id: str = Path(description="_id of the team to delete, must be in the form T1234",max_length=5, pattern=r"^T\d{4}$")):
    return crud.delete_team(_id)

#---------Match------------------------------------

class match_entity_model(BaseModel):
    team_id: str
    score: int

class match_model(BaseModel):
    match_no: int
    tournament_id: str
    entity1: match_entity_model
    entity2: match_entity_model
    scheduled_at: datetime
    status: str | None = None
    winner: int | None = None

@app.post("/match")
async def create_match(match: match_model):
    return crud.create_match(match.model_dump())

@app.get("/match/{_id}")
async def get_match_by_id(_id: str = Path(description="_id of the match to find, must be in the form M1234",max_length=5, pattern=r"^M\d{4}$")):
    return crud.get_match(_id)

@app.post("/match/query")
async def get_match(query: dict = Body(...,description="Query info in MongoDB query format")):
    return crud.get_matches_by_query(query)

@app.get("/match/tournament/{tournament_id}")
async def get_matches_by_tournament(tournament_id: str = Path(description="_id of the tournament, must be in the form N1234",max_length=5, pattern=r"^N\d{4}$")):
    return crud.get_matches_by_tournament(tournament_id)

@app.patch("/match/{_id}")
async def update_match(_id: str = Path(description="_id of the match to update, must be in the form M1234",max_length=5, pattern=r"^M\d{4}$"),
                       fields: dict = Body(...,description="fields and the value to update to")):
    return crud.update_match(_id, fields)

@app.delete("/match/{_id}")
async def delete_match(_id: str = Path(description="_id of the match to delete, must be in the form M1234",max_length=5, pattern=r"^M\d{4}$")):
    return crud.delete_match(_id)

@app.post("/match/{_id}/score",description="{ 'entity': 1 or 2, 'inc': int }")
async def increment_match_score(_id: str = Path(description="_id of the match to update score for, must be in the form M1234",max_length=5, pattern=r"^M\d{4}$"),
                                payload: dict = Body(...,description="{ 'entity': 1 or 2, 'inc_val': int }")):
    entity = int(payload.get("entity", 1))
    inc_val = int(payload.get("inc", 1))
    return crud.inc_match_score(_id, entity, inc_val)

@app.get("/match/{_id}/full")
async def get_full_match_view(_id: str = Path(description="_id of the match to view fully, must be in the form M1234",max_length=5, pattern=r"^M\d{4}$")):
    result = crud.full_match_view(_id)
    return result if result is not None else None

@app.get("/match/tournament/{tournament_id}/completed")
async def get_completed_matches(tournament_id: str = Path(description="_id of the tournament, must be in the form N1234",max_length=5, pattern=r"^N\d{4}$")):
    completed_matches = crud.get_completed_matches(tournament_id)
    return list(completed_matches) if completed_matches is not None else None

@app.get("/match/tournament/{tournament_id}/current")
async def get_current_matches(tournament_id: str = Path(description="_id of the tournament, must be in the form N1234",max_length=5, pattern=r"^N\d{4}$"),
                              ongoing_only: Annotated[bool, Query(description="returns only ongoing matches if true, else both ongoing and scheduled")]=False):
    q = {"tournament_id": tournament_id,"status": "ongoing"} if ongoing_only else {"tournament_id": tournament_id,"status": {"$in":["ongoing","completed"]}}
    logger.debug(f"query of generated {q}")
    return crud.get_matches_by_query(q)

@app.get("/match/tournament/{tournament_id}/next")
async def get_next_match(tournament_id: str = Path(description="_id of the tournament, must be in the form N1234",max_length=5, pattern=r"^N\d{4}$")):
    return crud.next_match_in_tournament(tournament_id)

@app.post("/match/{_id}/start_end",description="Starts a match if it has not started, ends it if it is going on")
async def start_end_match(_id:str = Path(description="_id of the match to to start or end, must be in the form M1234",max_length=5, pattern=r"^M\d{4}$")):
    return crud.start_end_match(_id)



#---------Tournament--------------------------------

class tournament_model(BaseModel):
    tournament_name: str
    sports: str
    start_date: datetime
    end_date: datetime
    location: str | Dict[str, Any]
    participants: list[Dict[str, Any]]
    status: str | None = None
    type: str

@app.post("/tournament")
async def create_tournament(tournament: tournament_model):
    return crud.create_tournament(tournament.model_dump())

@app.post("/tournament/query")
async def get_tournament(query: dict = Body(...,description="Query info in MongoDB query format")):
    return crud.get_tournaments_by_query(query)

@app.get("/tournament/search")
async def search_tournaments_by_name(name: Annotated[str, Query(..., min_length=1, description="Tournament name or partial name to search, case-insensitive")]):
    return crud.get_tournaments_by_name(name)

@app.get("/tournament/all")
async def get_all_tournaments():
    return crud.get_tournaments_by_query({})

@app.get("/tournament/{_id}")
async def get_tournament_by_id(_id: str = Path(description="_id of the tournament to find, must be in the form N1234",max_length=5, pattern=r"^N\d{4}$")):
    return crud.get_tournament(_id)

@app.patch("/tournament/{_id}")
async def update_tournament(_id: str = Path(description="_id of the tournament to update, must be in the form N1234",max_length=5, pattern=r"^N\d{4}$"),
                            fields: dict = Body(...,description="fields and the value to update to")):
    return crud.update_tournament(_id, fields)

@app.delete("/tournament/{_id}")
async def delete_tournament(_id: str = Path(description="_id of the tournament to delete, must be in the form N1234",max_length=5, pattern=r"^N\d{4}$")):
    return crud.delete_tournament(_id)

@app.delete("/tournament/{_id}/cascade")
async def delete_tournament_cascade(_id: str = Path(description="_id of the tournament to delete along with its matches, must be in the form N1234",max_length=5, pattern=r"^N\d{4}$")):
    return crud.delete_tournament_cascade(_id)

@app.get("/tournament/{_id}/teams")
async def get_tournament_teams(_id: str = Path(description="_id of the tournament to view teams for, must be in the form N1234",max_length=5, pattern=r"^N\d{4}$"),
                               playing_filter: Annotated[int,Query(description="playing_filter = 1 => currently playing teams;\n -1 => not currently playing\n; 0 => all")] = 0,
                               search_name: Annotated[str,Query(description="search the name of the team in a given tournament")] = ""):
    teams = crud.full_team_view(_id, playing_filter, search_name)
    return list(teams) if teams is not None else None

@app.get("/tournament/{_id}/generate", description="Generate match fixtures for a tournament")
async def generate_tournament_matches(_id: str = Path(description="_id of the tournament to generate matches, must be in the form N1234",max_length=5, pattern=r"^N\d{4}$")):
    try:
        generated_matches = crud.generate_matches_for_tournament(_id)
        return {"tournament_id": _id, "generated_matches": generated_matches}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))