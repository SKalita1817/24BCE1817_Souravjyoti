"""
Tournament Management System — Textual TUI
Connects to the FastAPI backend described in openapi.json.

Usage:
    pip install textual httpx
    python tournament_tui.py [--base-url http://localhost:8000]
"""

import argparse
import asyncio
import json
from datetime import datetime
from typing import Any

import httpx
from textual import on, work
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal, ScrollableContainer, Vertical
from textual.reactive import reactive
from textual.screen import ModalScreen, Screen
from textual.widgets import (
    Button,
    DataTable,
    Footer,
    Header,
    Input,
    Label,
    ListItem,
    ListView,
    Pretty,
    Select,
    Static,
    Tab,
    TabbedContent,
    TabPane,
    TextArea,
)

# ──────────────────────────────────────────────────────────────────────────────
# CONFIG
# ──────────────────────────────────────────────────────────────────────────────
BASE_URL = "http://localhost:8000"


# ──────────────────────────────────────────────────────────────────────────────
# HTTP HELPERS
# ──────────────────────────────────────────────────────────────────────────────
async def api(method: str, path: str, **kwargs) -> tuple[int, Any]:
    """Thin async wrapper around httpx. Returns (status_code, parsed_body)."""
    try:
        async with httpx.AsyncClient(base_url=BASE_URL, timeout=10) as client:
            resp = await client.request(method, path, **kwargs)
            try:
                body = resp.json()
            except Exception:
                body = resp.text
            return resp.status_code, body
    except httpx.RequestError as exc:
        return 503, f"Unable to connect to server at {BASE_URL}: {exc}"


# ──────────────────────────────────────────────────────────────────────────────
# REUSABLE MODAL — shows API response as JSON
# ──────────────────────────────────────────────────────────────────────────────
class ResponseModal(ModalScreen):
    BINDINGS = [Binding("escape,q", "dismiss", "Close")]

    def __init__(self, title: str, data: Any):
        super().__init__()
        self._title = title
        self._data = data

    def compose(self) -> ComposeResult:
        with Container(id="modal-box"):
            yield Label(self._title, id="modal-title")
            yield Pretty(self._data, id="modal-pretty")
            yield Button("Close  [Esc]", id="modal-close", variant="primary")

    @on(Button.Pressed, "#modal-close")
    def close(self) -> None:
        self.dismiss()


# ──────────────────────────────────────────────────────────────────────────────
# CONFIRM MODAL — Yes / No
# ──────────────────────────────────────────────────────────────────────────────
class ConfirmModal(ModalScreen[bool]):
    BINDINGS = [Binding("escape", "dismiss_false", "Cancel")]

    def __init__(self, message: str):
        super().__init__()
        self._message = message

    def compose(self) -> ComposeResult:
        with Container(id="modal-box"):
            yield Label(self._message, id="modal-title")
            with Horizontal(id="confirm-btns"):
                yield Button("Yes", id="btn-yes", variant="error")
                yield Button("No", id="btn-no", variant="primary")

    @on(Button.Pressed, "#btn-yes")
    def yes(self) -> None:
        self.dismiss(True)

    @on(Button.Pressed, "#btn-no")
    def no(self) -> None:
        self.dismiss(False)

    def action_dismiss_false(self) -> None:
        self.dismiss(False)


# ──────────────────────────────────────────────────────────────────────────────
# SHARED STATUS BANNER
# ──────────────────────────────────────────────────────────────────────────────
class StatusBanner(Static):
    def set_ok(self, msg: str) -> None:
        self.update(f"[bold green]✔ {msg}[/]")
        self.add_class("ok")
        self.remove_class("err")

    def set_err(self, msg: str) -> None:
        self.update(f"[bold red]✘ {msg}[/]")
        self.add_class("err")
        self.remove_class("ok")

    def clear(self) -> None:
        self.update("")


# ──────────────────────────────────────────────────────────────────────────────
# ── PLAYERS TAB ──────────────────────────────────────────────────────────────
# ──────────────────────────────────────────────────────────────────────────────
class PlayersTab(TabPane):
    def __init__(self):
        super().__init__("🛉 Players", id="tab-players")

    def compose(self) -> ComposeResult:
        yield StatusBanner(id="player-status")
        with TabbedContent(id="player-subtabs"):
            with TabPane("Search / Browse", id="psub-search"):
                yield Label("Search by Name  (leave blank → use ID below)", classes="form-label")
                yield Input(placeholder="e.g. Ravi", id="player-search-input")
                yield Label("  — OR —  Fetch by ID  (P0001)", classes="form-label")
                yield Input(placeholder="P0001", id="player-id-input")
                with Horizontal(classes="btn-row"):
                    yield Button("Search by Name", id="player-search-btn", variant="primary")
                    yield Button("Fetch by ID", id="player-fetch-btn")
                    yield Button("List All", id="player-all-btn")
                yield DataTable(id="player-table", cursor_type="row")

            with TabPane("Create", id="psub-create"):
                yield Label("Player Name *", classes="form-label")
                yield Input(placeholder="Full name", id="pc-name")
                yield Label("Gender *  (Male / Female / Other)", classes="form-label")
                yield Select([("Male", "M"), ("Female", "F")], id="pc-gender", prompt="Select Gender")
                yield Label("Date of Birth *  (YYYY-MM-DD)", classes="form-label")
                yield Input(placeholder="2000-01-15", id="pc-dob")
                yield Label("Contact  (JSON, e.g. {\"phone\":\"9876543210\"})", classes="form-label")
                yield Input(placeholder='{"phone":"9876543210"}', id="pc-contact")
                with Horizontal(classes="btn-row"):
                    yield Button("Create Player", id="player-create-btn", variant="success")

            with TabPane("Update / Delete", id="psub-update"):
                yield Label("Player ID  (P0001) *", classes="form-label")
                yield Input(placeholder="P0001", id="pu-id")
                yield Label("Fields to update  (JSON, e.g. {\"age\": 25})", classes="form-label")
                yield TextArea(id="pu-fields", language="json")
                with Horizontal(classes="btn-row"):
                    yield Button("Update", id="player-update-btn", variant="warning")
                    yield Button("Delete", id="player-delete-btn", variant="error")

    def on_mount(self) -> None:
        table = self.query_one("#player-table", DataTable)
        table.add_columns("ID", "Name", "Gender", "Age", "DOB")

    # ── List all
    @on(Button.Pressed, "#player-all-btn")
    @work(exclusive=True)
    async def list_all_players(self) -> None:
        code, data = await api("GET", "/player/all")
        self._populate_table(code, data)

    # ── Search by name
    @on(Button.Pressed, "#player-search-btn")
    @work(exclusive=True)
    async def search_players(self) -> None:
        name = self.query_one("#player-search-input", Input).value.strip()
        if not name:
            self.query_one("#player-status", StatusBanner).set_err("Enter a name to search.")
            return
        code, data = await api("GET", "/player/search", params={"name": name})
        self._populate_table(code, data)

    # ── Fetch by ID
    @on(Button.Pressed, "#player-fetch-btn")
    @work(exclusive=True)
    async def fetch_player(self) -> None:
        pid = self.query_one("#player-id-input", Input).value.strip()
        if not pid:
            self.query_one("#player-status", StatusBanner).set_err("Enter a player ID.")
            return
        code, data = await api("GET", f"/player/{pid}")
        if code == 200:
            players = data if isinstance(data, list) else [data]
            self._populate_table(code, players)
        else:
            self.query_one("#player-status", StatusBanner).set_err(str(data))

    def _populate_table(self, code: int, data: Any) -> None:
        table = self.query_one("#player-table", DataTable)
        table.clear()
        if code != 200:
            self.query_one("#player-status", StatusBanner).set_err(str(data))
            return
        players = data if isinstance(data, list) else [data]
        for p in players:
            table.add_row(
                p.get("_id", ""),
                p.get("player_name", ""),
                p.get("gender", ""),
                str(p.get("age", "")),
                str(p.get("dob", ""))[:10],
            )
        self.query_one("#player-status", StatusBanner).set_ok(f"{len(players)} record(s) loaded.")

    # ── Create player
    @on(Button.Pressed, "#player-create-btn")
    @work(exclusive=True)
    async def create_player(self) -> None:
        name = self.query_one("#pc-name", Input).value.strip()
        gender = self.query_one("#pc-gender", Select).value
        dob = self.query_one("#pc-dob", Input).value.strip()
        
        contact_raw = self.query_one("#pc-contact", Input).value.strip()

        if not (name and gender and dob):
            self.query_one("#player-status", StatusBanner).set_err("Name, Gender and DOB are required.")
            return

        try:
            contact = json.loads(contact_raw) if contact_raw else {}
        except json.JSONDecodeError:
            self.query_one("#player-status", StatusBanner).set_err("Contact must be valid JSON.")
            return

        dob_iso = dob + "T00:00:00Z" if "T" not in dob else dob
        payload: dict = {"player_name": name, "gender": gender, "dob": dob_iso, "contact": contact}

        code, data = await api("POST", "/player", json=payload)
        banner = self.query_one("#player-status", StatusBanner)
        if code == 200:
            banner.set_ok("Player created successfully.")
        else:
            banner.set_err(str(data))
        self.app.push_screen(ResponseModal("Create Player Response", data))

    # ── Update player
    @on(Button.Pressed, "#player-update-btn")
    @work(exclusive=True)
    async def update_player(self) -> None:
        pid = self.query_one("#pu-id", Input).value.strip()
        fields_raw = self.query_one("#pu-fields", TextArea).text.strip()
        if not pid or not fields_raw:
            self.query_one("#player-status", StatusBanner).set_err("ID and update fields are required.")
            return
        try:
            fields = json.loads(fields_raw)
        except json.JSONDecodeError:
            self.query_one("#player-status", StatusBanner).set_err("Fields must be valid JSON.")
            return
        code, data = await api("PATCH", f"/player/{pid}", json=fields)
        banner = self.query_one("#player-status", StatusBanner)
        banner.set_ok("Updated.") if code == 200 else banner.set_err(str(data))
        self.app.push_screen(ResponseModal("Update Player Response", data))

    # ── Delete player
    @on(Button.Pressed, "#player-delete-btn")
    @work(exclusive=True)
    async def delete_player(self) -> None:
        pid = self.query_one("#pu-id", Input).value.strip()
        if not pid:
            self.query_one("#player-status", StatusBanner).set_err("Enter a Player ID to delete.")
            return

        async def do_delete(confirmed: bool) -> None:
            if not confirmed:
                return
            code, data = await api("DELETE", f"/player/{pid}")
            banner = self.query_one("#player-status", StatusBanner)
            banner.set_ok("Deleted.") if code == 200 else banner.set_err(str(data))
            self.app.push_screen(ResponseModal("Delete Player Response", data))

        await self.app.push_screen_wait(ConfirmModal(f"Delete player {pid}?"))
        confirmed = self.app.return_value if hasattr(self.app, "return_value") else False
        # Use push_screen_wait properly
        confirmed = await self.app.push_screen_wait(ConfirmModal(f"Confirm delete {pid}?"))
        await do_delete(confirmed)


# ──────────────────────────────────────────────────────────────────────────────
# ── TEAMS TAB ────────────────────────────────────────────────────────────────
# ──────────────────────────────────────────────────────────────────────────────
class TeamsTab(TabPane):
    def __init__(self):
        super().__init__("⚑ Teams", id="tab-teams")

    def compose(self) -> ComposeResult:
        yield StatusBanner(id="team-status")
        with TabbedContent(id="team-subtabs"):
            with TabPane("Search / Browse", id="tsub-search"):
                yield Label("Search by Name", classes="form-label")
                yield Input(placeholder="e.g. Warriors", id="team-search-input")
                yield Label("  — OR —  Fetch by ID  (T0001)", classes="form-label")
                yield Input(placeholder="T0001", id="team-id-input")
                with Horizontal(classes="btn-row"):
                    yield Button("Search", id="team-search-btn", variant="primary")
                    yield Button("Fetch by ID", id="team-fetch-btn")
                    yield Button("List All", id="team-all-btn")
                yield DataTable(id="team-table", cursor_type="row")

            with TabPane("Create", id="tsub-create"):
                yield Label("Team Name *", classes="form-label")
                yield Input(placeholder="Warriors FC", id="tc-name")
                yield Label("Sport *", classes="form-label")
                yield Input(placeholder="Football", id="tc-sport")
                yield Label("Members  (JSON array, e.g. [{\"player_id\":\"P0001\",\"role\":\"Captain\"}])", classes="form-label")
                yield TextArea(id="tc-members", language="json")
                with Horizontal(classes="btn-row"):
                    yield Button("Create Team", id="team-create-btn", variant="success")

            with TabPane("Update / Delete", id="tsub-update"):
                yield Label("Team ID  (T0001) *", classes="form-label")
                yield Input(placeholder="T0001", id="tu-id")
                yield Label("Fields to update  (JSON)", classes="form-label")
                yield TextArea(id="tu-fields", language="json")
                with Horizontal(classes="btn-row"):
                    yield Button("Update", id="team-update-btn", variant="warning")
                    yield Button("Delete", id="team-delete-btn", variant="error")

    def on_mount(self) -> None:
        table = self.query_one("#team-table", DataTable)
        table.add_columns("ID", "Team Name", "Sport", "Members #")

    @on(Button.Pressed, "#team-all-btn")
    @work(exclusive=True)
    async def list_all_teams(self) -> None:
        code, data = await api("GET", "/team/all")
        self._populate_table(code, data)

    @on(Button.Pressed, "#team-search-btn")
    @work(exclusive=True)
    async def search_teams(self) -> None:
        name = self.query_one("#team-search-input", Input).value.strip()
        if not name:
            self.query_one("#team-status", StatusBanner).set_err("Enter a name.")
            return
        code, data = await api("GET", "/team/search", params={"name": name})
        self._populate_table(code, data)

    @on(Button.Pressed, "#team-fetch-btn")
    @work(exclusive=True)
    async def fetch_team(self) -> None:
        tid = self.query_one("#team-id-input", Input).value.strip()
        if not tid:
            return
        code, data = await api("GET", f"/team/{tid}")
        players = data if isinstance(data, list) else [data]
        self._populate_table(code, players)

    def _populate_table(self, code: int, data: Any) -> None:
        table = self.query_one("#team-table", DataTable)
        table.clear()
        if code != 200:
            self.query_one("#team-status", StatusBanner).set_err(str(data))
            return
        teams = data if isinstance(data, list) else [data]
        for t in teams:
            table.add_row(t.get("_id", ""), t.get("team_name", ""), t.get("sport", ""), str(len(t.get("members", []))))
        self.query_one("#team-status", StatusBanner).set_ok(f"{len(teams)} team(s) loaded.")

    @on(Button.Pressed, "#team-create-btn")
    @work(exclusive=True)
    async def create_team(self) -> None:
        name = self.query_one("#tc-name", Input).value.strip()
        sport = self.query_one("#tc-sport", Input).value.strip()
        members_raw = self.query_one("#tc-members", TextArea).text.strip()
        if not (name and sport):
            self.query_one("#team-status", StatusBanner).set_err("Name and Sport are required.")
            return
        try:
            members = json.loads(members_raw) if members_raw else []
        except json.JSONDecodeError:
            self.query_one("#team-status", StatusBanner).set_err("Members must be a valid JSON array.")
            return
        code, data = await api("POST", "/team", json={"team_name": name, "sport": sport, "members": members})
        banner = self.query_one("#team-status", StatusBanner)
        banner.set_ok("Team created.") if code == 200 else banner.set_err(str(data))
        self.app.push_screen(ResponseModal("Create Team Response", data))

    @on(Button.Pressed, "#team-update-btn")
    @work(exclusive=True)
    async def update_team(self) -> None:
        tid = self.query_one("#tu-id", Input).value.strip()
        fields_raw = self.query_one("#tu-fields", TextArea).text.strip()
        if not tid or not fields_raw:
            return
        try:
            fields = json.loads(fields_raw)
        except json.JSONDecodeError:
            self.query_one("#team-status", StatusBanner).set_err("Invalid JSON.")
            return
        code, data = await api("PATCH", f"/team/{tid}", json=fields)
        banner = self.query_one("#team-status", StatusBanner)
        banner.set_ok("Updated.") if code == 200 else banner.set_err(str(data))
        self.app.push_screen(ResponseModal("Update Team Response", data))

    @on(Button.Pressed, "#team-delete-btn")
    @work(exclusive=True)
    async def delete_team(self) -> None:
        tid = self.query_one("#tu-id", Input).value.strip()
        if not tid:
            return
        confirmed = await self.app.push_screen_wait(ConfirmModal(f"Delete team {tid}?"))
        if confirmed:
            code, data = await api("DELETE", f"/team/{tid}")
            banner = self.query_one("#team-status", StatusBanner)
            banner.set_ok("Deleted.") if code == 200 else banner.set_err(str(data))
            self.app.push_screen(ResponseModal("Delete Team Response", data))


# ──────────────────────────────────────────────────────────────────────────────
# ── TOURNAMENTS TAB ──────────────────────────────────────────────────────────
# ──────────────────────────────────────────────────────────────────────────────
class TournamentsTab(TabPane):
    def __init__(self):
        super().__init__("【1ˢᵗ】 Tournaments", id="tab-tournaments")

    def compose(self) -> ComposeResult:
        yield StatusBanner(id="tourn-status")
        with TabbedContent(id="tourn-subtabs"):
            with TabPane("Search / Browse", id="nsub-search"):
                yield Label("Search by Name", classes="form-label")
                yield Input(placeholder="e.g. Premier", id="tourn-search-input")
                yield Label("  — OR —  Fetch by ID  (N0001)", classes="form-label")
                yield Input(placeholder="N0001", id="tourn-id-input")
                with Horizontal(classes="btn-row"):
                    yield Button("Search", id="tourn-search-btn", variant="primary")
                    yield Button("Fetch by ID", id="tourn-fetch-btn")
                    yield Button("List All", id="tourn-all-btn")
                yield DataTable(id="tourn-table", cursor_type="row")

            with TabPane("Create", id="nsub-create"):
                with ScrollableContainer():
                    yield Label("Tournament Name *", classes="form-label")
                    yield Input(placeholder="Premier Cup 2025", id="nc-name")
                    yield Label("Sport *", classes="form-label")
                    yield Input(placeholder="Cricket", id="nc-sport")
                    yield Label("Type *  (knockout / cyclic)", classes="form-label")
                    yield Select([("knockout", "knockout"), ("cyclic", "cyclic")], id="nc-type", prompt="Select type")
                    yield Label("Start Date *  (YYYY-MM-DD)", classes="form-label")
                    yield Input(placeholder="2025-01-01", id="nc-start")
                    yield Label("End Date *  (YYYY-MM-DD)", classes="form-label")
                    yield Input(placeholder="2025-02-28", id="nc-end")
                    yield Label("Location  (string or JSON object)", classes="form-label")
                    yield Input(placeholder='Mumbai or {"city":"Mumbai","country":"India"}', id="nc-location")
                    yield Label("Participants  (JSON array, e.g. [{\"team_id\":\"T0001\",\"playing\":true}])", classes="form-label")
                    yield TextArea(id="nc-participants", language="json")
                    with Horizontal(classes="btn-row"):
                        yield Button("Create Tournament", id="tourn-create-btn", variant="success")

            with TabPane("Update / Delete", id="nsub-update"):
                yield Label("Tournament ID  (N0001) *", classes="form-label")
                yield Input(placeholder="N0001", id="nu-id")
                yield Label("Fields to update  (JSON)", classes="form-label")
                yield TextArea(id="nu-fields", language="json")
                with Horizontal(classes="btn-row"):
                    yield Button("Update", id="tourn-update-btn", variant="warning")
                    yield Button("Delete", id="tourn-delete-btn", variant="error")

            with TabPane("Teams in Tournament", id="nsub-teams"):
                yield Label("Tournament ID  (N0001) *", classes="form-label")
                yield Input(placeholder="N0001", id="nt-tourn-id")
                yield Label("Playing Filter:  1=playing  -1=not playing  0=all", classes="form-label")
                yield Select(
                    [("All (0)", "0"), ("Currently Playing (1)", "1"), ("Not Playing (-1)", "-1")],
                    id="nt-playing-filter",
                    prompt="Filter",
                )
                yield Label("Search team name (optional)", classes="form-label")
                yield Input(placeholder="Warriors", id="nt-name-search")
                with Horizontal(classes="btn-row"):
                    yield Button("Fetch Teams", id="tourn-teams-btn", variant="primary")
                yield DataTable(id="nt-table", cursor_type="row")

            with TabPane("Generate Fixtures", id="nsub-generate"):
                yield Label("Tournament ID  (N0001) *", classes="form-label")
                yield Input(placeholder="N0001", id="ng-tourn-id")
                yield Label("Generates the tournament fixtures and creates the match schedule.", classes="form-label")
                with Horizontal(classes="btn-row"):
                    yield Button("Generate Fixtures", id="tourn-generate-btn", variant="warning")

    def on_mount(self) -> None:
        self.query_one("#tourn-table", DataTable).add_columns("ID", "Name", "Sport", "Type", "Status", "Start", "End")
        self.query_one("#nt-table", DataTable).add_columns("Team ID", "Team Name", "Sport", "Playing")

    @on(Button.Pressed, "#tourn-all-btn")
    @work(exclusive=True)
    async def list_all_tournaments(self) -> None:
        code, data = await api("GET", "/tournament/all")
        self._populate_table(code, data)

    @on(Button.Pressed, "#tourn-search-btn")
    @work(exclusive=True)
    async def search_tournaments(self) -> None:
        name = self.query_one("#tourn-search-input", Input).value.strip()
        if not name:
            self.query_one("#tourn-status", StatusBanner).set_err("Enter a name.")
            return
        code, data = await api("GET", "/tournament/search", params={"name": name})
        self._populate_table(code, data)

    @on(Button.Pressed, "#tourn-fetch-btn")
    @work(exclusive=True)
    async def fetch_tournament(self) -> None:
        nid = self.query_one("#tourn-id-input", Input).value.strip()
        if not nid:
            return
        code, data = await api("GET", f"/tournament/{nid}")
        self._populate_table(code, data if isinstance(data, list) else [data])

    def _populate_table(self, code: int, data: Any) -> None:
        table = self.query_one("#tourn-table", DataTable)
        table.clear()
        if code != 200:
            self.query_one("#tourn-status", StatusBanner).set_err(str(data))
            return
        items = data if isinstance(data, list) else [data]
        for t in items:
            table.add_row(
                t.get("_id", ""),
                t.get("tournament_name", ""),
                t.get("sports", ""),
                t.get("type", ""),
                t.get("status", ""),
                str(t.get("start_date", ""))[:10],
                str(t.get("end_date", ""))[:10],
            )
        self.query_one("#tourn-status", StatusBanner).set_ok(f"{len(items)} record(s).")

    @on(Button.Pressed, "#tourn-create-btn")
    @work(exclusive=True)
    async def create_tournament(self) -> None:
        name = self.query_one("#nc-name", Input).value.strip()
        sport = self.query_one("#nc-sport", Input).value.strip()
        t_type = self.query_one("#nc-type", Select).value
        start = self.query_one("#nc-start", Input).value.strip()
        end = self.query_one("#nc-end", Input).value.strip()
        location_raw = self.query_one("#nc-location", Input).value.strip()
        participants_raw = self.query_one("#nc-participants", TextArea).text.strip()

        if not all([name, sport, t_type, start, end, location_raw]):
            self.query_one("#tourn-status", StatusBanner).set_err("Fill all required fields.")
            return

        try:
            location = json.loads(location_raw) if location_raw.startswith("{") else location_raw
            participants = json.loads(participants_raw) if participants_raw else []
        except json.JSONDecodeError:
            self.query_one("#tourn-status", StatusBanner).set_err("Invalid JSON in location or participants.")
            return

        payload = {
            "tournament_name": name,
            "sports": sport,
            "type": t_type,
            "start_date": start + "T00:00:00",
            "end_date": end + "T00:00:00",
            "location": location,
            "participants": participants,
        }
        code, data = await api("POST", "/tournament", json=payload)
        banner = self.query_one("#tourn-status", StatusBanner)
        banner.set_ok("Tournament created.") if code == 200 else banner.set_err(str(data))
        self.app.push_screen(ResponseModal("Create Tournament Response", data))

    @on(Button.Pressed, "#tourn-update-btn")
    @work(exclusive=True)
    async def update_tournament(self) -> None:
        nid = self.query_one("#nu-id", Input).value.strip()
        fields_raw = self.query_one("#nu-fields", TextArea).text.strip()
        if not nid or not fields_raw:
            return
        try:
            fields = json.loads(fields_raw)
        except json.JSONDecodeError:
            self.query_one("#tourn-status", StatusBanner).set_err("Invalid JSON.")
            return
        code, data = await api("PATCH", f"/tournament/{nid}", json=fields)
        banner = self.query_one("#tourn-status", StatusBanner)
        banner.set_ok("Updated.") if code == 200 else banner.set_err(str(data))
        self.app.push_screen(ResponseModal("Update Tournament Response", data))

    @on(Button.Pressed, "#tourn-delete-btn")
    @work(exclusive=True)
    async def delete_tournament(self) -> None:
        nid = self.query_one("#nu-id", Input).value.strip()
        if not nid:
            return
        confirmed = await self.app.push_screen_wait(ConfirmModal(f"Delete tournament {nid}?"))
        if confirmed:
            code, data = await api("DELETE", f"/tournament/{nid}")
            banner = self.query_one("#tourn-status", StatusBanner)
            banner.set_ok("Deleted.") if code == 200 else banner.set_err(str(data))
            self.app.push_screen(ResponseModal("Delete Tournament Response", data))

    @on(Button.Pressed, "#tourn-teams-btn")
    @work(exclusive=True)
    async def fetch_tourn_teams(self) -> None:
        nid = self.query_one("#nt-tourn-id", Input).value.strip()
        if not nid:
            self.query_one("#tourn-status", StatusBanner).set_err("Enter a Tournament ID.")
            return
        pf = self.query_one("#nt-playing-filter", Select).value or "0"
        sn = self.query_one("#nt-name-search", Input).value.strip()
        code, data = await api(
            "GET",
            f"/tournament/{nid}/teams",
            params={"playing_filter": pf, "search_name": sn},
        )
        table = self.query_one("#nt-table", DataTable)
        table.clear()
        if code != 200:
            self.query_one("#tourn-status", StatusBanner).set_err(str(data))
            return
        teams = data if isinstance(data, list) else [data]
        for t in teams:
            table.add_row(t.get("_id", ""), t.get("team_name", ""), t.get("sport", ""), str(t.get("playing", "")))
        self.query_one("#tourn-status", StatusBanner).set_ok(f"{len(teams)} team(s).")

    @on(Button.Pressed, "#tourn-generate-btn")
    @work(exclusive=True)
    async def generate_fixtures(self) -> None:
        nid = self.query_one("#ng-tourn-id", Input).value.strip()
        if not nid:
            self.query_one("#tourn-status", StatusBanner).set_err("Enter a Tournament ID.")
            return

        confirmed = await self.app.push_screen_wait(ConfirmModal(f"Generate fixtures for tournament {nid}?"))
        if not confirmed:
            return

        code, data = await api("GET", f"/tournament/{nid}/generate")
        banner = self.query_one("#tourn-status", StatusBanner)
        banner.set_ok("Fixtures generated.") if code == 200 else banner.set_err(str(data))
        self.app.push_screen(ResponseModal("Generate Fixtures Response", data))


# ──────────────────────────────────────────────────────────────────────────────
# ── MATCHES TAB ──────────────────────────────────────────────────────────────
# ──────────────────────────────────────────────────────────────────────────────
class MatchesTab(TabPane):
    def __init__(self):
        super().__init__("♔♛ Matches", id="tab-matches")

    def compose(self) -> ComposeResult:
        yield StatusBanner(id="match-status")
        with TabbedContent(id="match-subtabs"):
            with TabPane("Browse", id="msub-browse"):
                yield Label("Match ID  (M0001)", classes="form-label")
                yield Input(placeholder="M0001", id="match-id-input")
                yield Label("  — OR —  Tournament ID  (N0001)", classes="form-label")
                yield Input(placeholder="N0001", id="match-tourn-input")
                with Horizontal(classes="btn-row"):
                    yield Button("Fetch by ID", id="match-fetch-btn", variant="primary")
                    yield Button("By Tournament", id="match-tourn-btn")
                    yield Button("Full View", id="match-full-btn")
                yield DataTable(id="match-table", cursor_type="row")

            with TabPane("Create", id="msub-create"):
                with ScrollableContainer():
                    yield Label("Match No *  (integer)", classes="form-label")
                    yield Input(placeholder="1", id="mc-no")
                    yield Label("Tournament ID *  (N0001)", classes="form-label")
                    yield Input(placeholder="N0001", id="mc-tourn")
                    yield Label("Team 1 ID *  (T0001)", classes="form-label")
                    yield Input(placeholder="T0001", id="mc-t1")
                    yield Label("Team 1 Score *  (initial, usually 0)", classes="form-label")
                    yield Input(placeholder="0", id="mc-t1s")
                    yield Label("Team 2 ID *  (T0002)", classes="form-label")
                    yield Input(placeholder="T0002", id="mc-t2")
                    yield Label("Team 2 Score *  (initial, usually 0)", classes="form-label")
                    yield Input(placeholder="0", id="mc-t2s")
                    yield Label("Scheduled At *  (YYYY-MM-DDTHH:MM:SS)", classes="form-label")
                    yield Input(placeholder="2025-06-15T14:30:00", id="mc-sched")
                    with Horizontal(classes="btn-row"):
                        yield Button("Create Match", id="match-create-btn", variant="success")

            with TabPane("Score / Update / Delete", id="msub-update"):
                with ScrollableContainer():
                    yield Label("Match ID  (M0001) *", classes="form-label")
                    yield Input(placeholder="M0001", id="mu-id")
                    yield Label("── Score Update ──", classes="section-label")
                    yield Label("Entity  (1 or 2), i.e which team should have the change", classes="form-label")
                    yield Select([("1st Entity/Team",1),("2nd Entity/Team",2)], id="mu-entity")
                    yield Label("Increment by", classes="form-label")
                    yield Input(placeholder="1", id="mu-inc")
                    yield Button("Update Score", id="match-score-btn", variant="warning")
                    yield Label("── Field Update ──", classes="section-label")
                    yield Label("Fields JSON  (e.g. {\"status\":\"ongoing\"})", classes="form-label")
                    yield TextArea(id="mu-fields", language="json")
                    with Horizontal(classes="btn-row"):
                        yield Button("Update Fields", id="match-update-btn", variant="warning")
                        yield Button("Start/End Match",id="match-start-end-btn",variant="warning")
                        yield Button("Delete Match", id="match-delete-btn", variant="error")

    def on_mount(self) -> None:
        table = self.query_one("#match-table", DataTable)
        table.add_columns("ID", "Match#", "Tournament", "Team1", "Score1", "Team2", "Score2", "Status", "Scheduled")

    @on(Button.Pressed, "#match-fetch-btn")
    @work(exclusive=True)
    async def fetch_match(self) -> None:
        mid = self.query_one("#match-id-input", Input).value.strip()
        if not mid:
            return
        code, data = await api("GET", f"/match/{mid}")
        self._populate_table(code, data if isinstance(data, list) else [data])

    @on(Button.Pressed, "#match-tourn-btn")
    @work(exclusive=True)
    async def fetch_by_tourn(self) -> None:
        nid = self.query_one("#match-tourn-input", Input).value.strip()
        if not nid:
            return
        code, data = await api("GET", f"/match/tournament/{nid}")
        self._populate_table(code, data)

    @on(Button.Pressed, "#match-full-btn")
    @work(exclusive=True)
    async def fetch_full(self) -> None:
        mid = self.query_one("#match-id-input", Input).value.strip()
        if not mid:
            self.query_one("#match-status", StatusBanner).set_err("Enter a Match ID.")
            return
        code, data = await api("GET", f"/match/{mid}/full")
        self.app.push_screen(ResponseModal(f"Full Match View — {mid}", data))


    def _populate_table(self, code: int, data: Any) -> None:
        table = self.query_one("#match-table", DataTable)
        table.clear()
        if code != 200:
            self.query_one("#match-status", StatusBanner).set_err(str(data))
            return
        matches = data if isinstance(data, list) else [data]
        for m in matches:
            e1 = m.get("entity1", {})
            e2 = m.get("entity2", {})
            table.add_row(
                m.get("_id", ""),
                str(m.get("match_no", "")),
                m.get("tournament_id", ""),
                e1.get("team_id", ""),
                str(e1.get("score", "")),
                e2.get("team_id", ""),
                str(e2.get("score", "")),
                m.get("status", ""),
                str(m.get("scheduled_at", "")),
            )
        self.query_one("#match-status", StatusBanner).set_ok(f"{len(matches)} match(es).")

    @on(Button.Pressed, "#match-create-btn")
    @work(exclusive=True)
    async def create_match(self) -> None:
        try:
            payload = {
                "match_no": int(self.query_one("#mc-no", Input).value),
                "tournament_id": self.query_one("#mc-tourn", Input).value.strip(),
                "entity1": {"team_id": self.query_one("#mc-t1", Input).value.strip(), "score": int(self.query_one("#mc-t1s", Input).value or 0)},
                "entity2": {"team_id": self.query_one("#mc-t2", Input).value.strip(), "score": int(self.query_one("#mc-t2s", Input).value or 0)},
                "scheduled_at": self.query_one("#mc-sched", Input).value.strip(),
            }
        except (ValueError, KeyError) as e:
            self.query_one("#match-status", StatusBanner).set_err(f"Invalid input: {e}")
            return
        code, data = await api("POST", "/match", json=payload)
        banner = self.query_one("#match-status", StatusBanner)
        banner.set_ok("Match created.") if code == 200 else banner.set_err(str(data))
        self.app.push_screen(ResponseModal("Create Match Response", data))

    @on(Button.Pressed, "#match-score-btn")
    @work(exclusive=True)
    async def update_score(self) -> None:
        mid = self.query_one("#mu-id", Input).value.strip()
        entity_raw = self.query_one("#mu-entity", Select).value
        inc_raw = self.query_one("#mu-inc", Input).value.strip()
        if not mid or not entity_raw or not inc_raw:
            self.query_one("#match-status", StatusBanner).set_err("Match ID, entity, and increment are required.")
            return
        payload = {"entity": entity_raw, "inc_val": int(inc_raw)}
        code, data = await api("POST", f"/match/{mid}/score", json=payload)
        banner = self.query_one("#match-status", StatusBanner)
        banner.set_ok("Score updated.") if code == 200 else banner.set_err(str(data))
        self.app.push_screen(ResponseModal("Score Update Response", data))

    @on(Button.Pressed, "#match-update-btn")
    @work(exclusive=True)
    async def update_match(self) -> None:
        mid = self.query_one("#mu-id", Input).value.strip()
        fields_raw = self.query_one("#mu-fields", TextArea).text.strip()
        if not mid or not fields_raw:
            return
        try:
            fields = json.loads(fields_raw)
        except json.JSONDecodeError:
            self.query_one("#match-status", StatusBanner).set_err("Invalid JSON.")
            return
        code, data = await api("PATCH", f"/match/{mid}", json=fields)
        banner = self.query_one("#match-status", StatusBanner)
        banner.set_ok("Updated.") if code == 200 else banner.set_err(str(data))
        self.app.push_screen(ResponseModal("Update Match Response", data))

    @on(Button.Pressed, "#match-start-end-btn")
    @work(exclusive=True)
    async def update_status(self) -> None:
        mid = self.query_one("#mu-id", Input).value.strip()
        if not mid:
            self.query_one("#match-status", StatusBanner).set_err("Enter a Match ID.")
            return
        code, data = await api("POST", f"/match/{mid}/start_end")
        self.app.push_screen(ResponseModal(f"Full Match View — {mid}", data))

    @on(Button.Pressed, "#match-delete-btn")
    @work(exclusive=True)
    async def delete_match(self) -> None:
        mid = self.query_one("#mu-id", Input).value.strip()
        if not mid:
            return
        confirmed = await self.app.push_screen_wait(ConfirmModal(f"Delete match {mid}?"))
        if confirmed:
            code, data = await api("DELETE", f"/match/{mid}")
            banner = self.query_one("#match-status", StatusBanner)
            banner.set_ok("Deleted.") if code == 200 else banner.set_err(str(data))
            self.app.push_screen(ResponseModal("Delete Match Response", data))


# ──────────────────────────────────────────────────────────────────────────────
# ── RAW QUERY TAB ─────────────────────────────────────────────────────────────
# ──────────────────────────────────────────────────────────────────────────────
class RawQueryTab(TabPane):
    def __init__(self):
        super().__init__("⌕ Raw Query", id="tab-query")

    def compose(self) -> ComposeResult:
        yield StatusBanner(id="query-status")
        yield Label("Collection", classes="form-label")
        yield Select(
            [("player", "player"), ("team", "team"), ("match", "match"), ("tournament", "tournament")],
            id="query-collection",
            prompt="Select collection",
        )
        yield Label("MongoDB Query  (JSON, e.g. {\"gender\":\"Male\"})", classes="form-label")
        yield TextArea(id="query-body", language="json")
        with Horizontal(classes="btn-row"):
            yield Button("Run Query", id="query-run-btn", variant="primary")
        yield DataTable(id="query-table", cursor_type="row")

    def on_mount(self) -> None:
        table = self.query_one("#query-table", DataTable)
        table.add_columns("_id", "Data Preview")

    @on(Button.Pressed, "#query-run-btn")
    @work(exclusive=True)
    async def run_query(self) -> None:
        coll = self.query_one("#query-collection", Select).value
        body_raw = self.query_one("#query-body", TextArea).text.strip()
        if not coll:
            self.query_one("#query-status", StatusBanner).set_err("Select a collection.")
            return
        try:
            body = json.loads(body_raw) if body_raw else {}
        except json.JSONDecodeError:
            self.query_one("#query-status", StatusBanner).set_err("Invalid JSON query.")
            return
        code, data = await api("POST", f"/{coll}/query", json=body)
        table = self.query_one("#query-table", DataTable)
        table.clear()
        if code != 200:
            self.query_one("#query-status", StatusBanner).set_err(str(data))
            return
        items = data if isinstance(data, list) else [data]
        for item in items:
            preview = json.dumps({k: v for k, v in item.items() if k != "_id"})[:80] + "…"
            table.add_row(item.get("_id", ""), preview)
        self.query_one("#query-status", StatusBanner).set_ok(f"{len(items)} result(s).")
        if items:
            self.app.push_screen(ResponseModal(f"Query Results ({coll})", items))


# ──────────────────────────────────────────────────────────────────────────────
# ── DASHBOARD TAB ─────────────────────────────────────────────────────────────
# ──────────────────────────────────────────────────────────────────────────────
class DashboardTab(TabPane):
    def __init__(self):
        super().__init__("🖳 Dashboard", id="tab-dashboard")

    def compose(self) -> ComposeResult:
        yield StatusBanner(id="dash-status")
        yield Button("↻  Refresh Dashboard", id="dash-refresh-btn", variant="primary")
        with Horizontal(id="dash-cards"):
            yield Static("", id="card-players", classes="dash-card")
            yield Static("", id="card-teams", classes="dash-card")
            yield Static("", id="card-tournaments", classes="dash-card")
            yield Static("", id="card-matches", classes="dash-card")
        yield Label("Recent Ongoing / Upcoming Matches", classes="section-label")
        yield DataTable(id="dash-match-table", cursor_type="row")

    def on_mount(self) -> None:
        table = self.query_one("#dash-match-table", DataTable)
        table.add_columns("ID", "Tournament", "Team1", "Score1", "Team2", "Score2", "Status", "Scheduled")
        self.load_dashboard()

    @on(Button.Pressed, "#dash-refresh-btn")
    def refresh_dashboard(self, event: Button.Pressed) -> None:
        self.load_dashboard()

    @work(exclusive=True)
    async def load_dashboard(self) -> None:
        banner = self.query_one("#dash-status", StatusBanner)
        banner.set_ok("Loading…")

        # Fetch counts via empty queries
        code, players = await api("POST", "/player/query", json={})
        if code != 200:
            banner.set_err(str(players))
            return

        code, teams = await api("POST", "/team/query", json={})
        if code != 200:
            banner.set_err(str(teams))
            return

        code, tournaments = await api("POST", "/tournament/query", json={})
        if code != 200:
            banner.set_err(str(tournaments))
            return

        code, matches = await api("POST", "/match/query", json={})
        if code != 200:
            banner.set_err(str(matches))
            return

        pc = len(players) if isinstance(players, list) else "?"
        tc = len(teams) if isinstance(teams, list) else "?"
        nc = len(tournaments) if isinstance(tournaments, list) else "?"
        mc = len(matches) if isinstance(matches, list) else "?"

        self.query_one("#card-players", Static).update(f"[bold cyan]Players[/]\n\n[bold white]{pc}[/]")
        self.query_one("#card-teams", Static).update(f"[bold green]Teams[/]\n\n[bold white]{tc}[/]")
        self.query_one("#card-tournaments", Static).update(f"[bold yellow]Tournaments[/]\n\n[bold white]{nc}[/]")
        self.query_one("#card-matches", Static).update(f"[bold magenta]Matches[/]\n\n[bold white]{mc}[/]")

        # Show ongoing / scheduled matches
        code, active = await api("POST", "/match/query", json={"status": {"$in": ["ongoing", "scheduled"]}})
        if code != 200:
            banner.set_err(str(active))
            return
        table = self.query_one("#dash-match-table", DataTable)
        table.clear()
        if isinstance(active, list):
            for m in active[:20]:
                e1 = m.get("entity1", {})
                e2 = m.get("entity2", {})
                table.add_row(
                    m.get("_id", ""),
                    m.get("tournament_id", ""),
                    e1.get("team_id", ""),
                    str(e1.get("score", "")),
                    e2.get("team_id", ""),
                    str(e2.get("score", "")),
                    m.get("status", ""),
                    str(m.get("scheduled_at", ""))[:16],
                )
        banner.set_ok(f"Dashboard loaded — {datetime.now().strftime('%H:%M:%S')}")


# ──────────────────────────────────────────────────────────────────────────────
# ── MAIN APP ──────────────────────────────────────────────────────────────────
# ──────────────────────────────────────────────────────────────────────────────
CSS = """
Screen {
    background: $surface;
}

Header {
    background: $primary-darken-2;
}

/* ── Modal ──────────────────────────────────────────── */
ResponseModal, ConfirmModal {
    align: center middle;
}

#modal-box {
    width: 80;
    max-height: 40;
    background: $panel;
    border: round $primary;
    padding: 1 2;
}

#modal-title {
    text-style: bold;
    color: $accent;
    margin-bottom: 1;
}

#modal-pretty {
    height: auto;
    max-height: 28;
    overflow-y: auto;
    border: solid $surface-lighten-1;
    padding: 0 1;
}

#confirm-btns {
    margin-top: 1;
    align: center middle;
    height: 3;
}

#confirm-btns Button {
    margin: 0 1;
}

/* ── Status banner ───────────────────────────────────── */
StatusBanner {
    height: 1;
    padding: 0 1;
}

StatusBanner.ok { color: $success; }
StatusBanner.err { color: $error; }

/* ── Form helpers ────────────────────────────────────── */
.form-label {
    color: $text-muted;
    margin-top: 1;
    height: 1;
}

.section-label {
    color: $accent;
    text-style: bold;
    margin-top: 1;
    height: 1;
}

.btn-row {
    height: 3;
    margin-top: 1;
}

.btn-row Button {
    margin-right: 1;
}

Input {
    margin-bottom: 0;
}

TextArea {
    height: 6;
    margin-bottom: 0;
}

/* ── Dashboard ───────────────────────────────────────── */
#dash-cards {
    height: 7;
    margin: 1 0;
}

.dash-card {
    border: round $primary;
    padding: 1 2;
    width: 1fr;
    text-align: center;
    content-align: center middle;
}

/* ── Tables ──────────────────────────────────────────── */
DataTable {
    height: 1fr;
    min-height: 8;
    margin-top: 1;
}

/* ── Tabs ────────────────────────────────────────────── */
TabbedContent {
    height: 1fr;
}

TabPane {
    padding: 1 2;
}
"""


class TournamentApp(App):
    TITLE = "Universal Tournament Management System"
    BINDINGS = [
        Binding("ctrl+q", "quit", "Quit"),
        Binding("ctrl+d", "switch_tab('tab-dashboard')", "Dashboard"),
        Binding("ctrl+p", "switch_tab('tab-players')", "Players"),
        Binding("ctrl+t", "switch_tab('tab-teams')", "Teams"),
        Binding("ctrl+n", "switch_tab('tab-tournaments')", "Tournaments"),
        Binding("ctrl+m", "switch_tab('tab-matches')", "Matches"),
    ]
    CSS = CSS

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        with TabbedContent(id="main-tabs"):
            yield DashboardTab()
            yield PlayersTab()
            yield TeamsTab()
            yield TournamentsTab()
            yield MatchesTab()
            yield RawQueryTab()
        yield Footer()

    def action_switch_tab(self, tab_id: str) -> None:
        self.query_one("#main-tabs", TabbedContent).active = tab_id


# ──────────────────────────────────────────────────────────────────────────────
# ENTRY POINT
# ──────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Tournament Management TUI")
    parser.add_argument("--base-url", default="http://localhost:8000", help="FastAPI backend URL")
    args = parser.parse_args()
    BASE_URL = args.base_url.rstrip("/")
    TournamentApp().run()