from pymongo import MongoClient,ASCENDING,DESCENDING
from pymongo.errors import PyMongoError
import logging
import re
from datetime import datetime, timezone, date
import random
from itertools import combinations

logger = logging.getLogger(__name__)




# ── Connection ────────────────────────────────────────────────────────────────

def establishDB():
    """Connect to MongoDB and initialise collection handles. Returns True on success."""
    try:
        global client, db, Player, Team, Match, Tournament

        client = MongoClient("mongodb://localhost:27017/")
        db = client["UniTournament"]
        Player = db["Player"]
        Team = db["Team"]
        Match = db["Match"]
        Tournament = db["Tournament"]
    
        logger.debug("Connected to MongoDB client")
        print("Connected to MongoDB client")
        return True
    except Exception as e:
        logger.exception("MongoDB connection failed")
        print("[!] Unable to connect to MongoDB")
        return False


def disconnectDB():
    """Close the MongoDB connection."""
    client.close()
    logger.debug("Disconnected from MongoDB")
    print("Disconnected from MongoDB")


# ── Generic helpers ───────────────────────────────────────────────────────────

def _insert_one(collection, document: dict):
    """Insert a single document. Returns the inserted_id or None."""
    try:
        result = collection.insert_one(document)
        logger.debug("Inserted document into %s", collection.name)
        return result.inserted_id
    except PyMongoError:
        logger.exception("Insert failed on %s", collection.name)
        return None


def _find_one(collection, query: dict):
    """Return the first document matching *query*, or None."""
    try:
        return collection.find_one(query)
    except PyMongoError:
        logger.exception("find_one failed on %s", collection.name)
        return None


def _find_many(collection, query: dict):
    """Return a list of all documents matching *query* (default: all documents)."""
    try:
        return list(collection.find(query or {}))
    except PyMongoError:
        logger.exception("find_many failed on %s", collection.name)
        return []


def _update_one(collection, query: dict, update_fields: dict):
    """Update the first document matching *query*. Returns modified_count."""
    try:
        result = collection.update_one(query, {"$set": update_fields})
        logger.debug("Updated %d doc(s) in %s", result.modified_count, collection.name)
        return result.modified_count
    except PyMongoError:
        logger.exception("update_one failed on %s", collection.name)
        return 0


def _delete_one(collection, query: dict):
    """Delete the first document matching *query*. Returns deleted_count."""
    try:
        result = collection.delete_one(query)
        logger.debug("Deleted %d doc(s) from %s", result.deleted_count, collection.name)
        return result.deleted_count
    except PyMongoError:
        logger.exception("delete_one failed on %s", collection.name)
        return 0


def _delete_many(collection, query: dict):
    """Delete all documents matching *query*. Returns deleted_count."""
    try:
        result = collection.delete_many(query)
        logger.debug("Deleted %d doc(s) from %s", result.deleted_count, collection.name)
        return result.deleted_count
    except PyMongoError:
        logger.exception("delete_many failed on %s", collection.name)
        return 0

def _count_documents(collection, query: dict = {}):
    """Return the number of documents in *collection* matching *query* (default: all documents)."""
    try:
        count = collection.count_documents(query or {})
        logger.debug("Counted %d doc(s) in %s", count, collection.name)
        return count
    except PyMongoError:
        logger.exception("count_documents failed on %s", collection.name)
        return 0

def _create_id(collection):
    '''Returns the new _id for a given collection'''
    IDprefix = {
        "Player" : "P",
        "Team" : "T",
        "Match": "M",
        "Tournament": "N"
    }
    count = _count_documents(collection)
    id = IDprefix[collection.name] + str(count+1).zfill(4)
    id_exists = lambda: collection.count_documents({"_id": id}, limit=1) > 0
    while id_exists():
        logger.debug(f"{id} already exists")
        count += 1
        id = IDprefix[collection.name] + str(count+1).zfill(4)

    logger.debug("Created ID for "+collection.name+": "+id)
    return id


def _calculate_age(dob: date | datetime) -> int:
    """Calculate age from a date of birth using the current date."""
    dob_date = dob.date() if isinstance(dob, datetime) else dob
    today = date.today()
    return today.year - dob_date.year - ((today.month, today.day) < (dob_date.month, dob_date.day))


# ── Player ────────────────────────────────────────────────────────────────────

def create_player(player: dict):
    """
    Insert a new player document.

    Expected fields (_id is optional):
        {
            "_id": str,
            "player_name": str,
            "gender":str,
            "contact":{},
            "age": int
            "dob": date
        }

    Returns the inserted _id, or None on failure.
    """
    player["_id"] = _create_id(Player)
    if "dob" in player:
        if player.get("age") is None:
            player["age"] = _calculate_age(player["dob"])
        logger.debug(f"Age calculated as {player['age']} for {player['_id']}")
    player["created_at"] = datetime.now(timezone.utc)
    return _insert_one(Player, player)


def get_player(player_id: str):
    """Fetch a player by player_id."""
    return _find_one(Player, {"_id": player_id})


def get_players_by_query(query: dict):
    """Fetch all players matching *query*. Pass None / {} to get every player."""
    return _find_many(Player, query)


def get_players_by_name(name: str):
    """Fetch players whose player_name matches *name* case-insensitively."""
    escaped_name = re.escape(name.strip())
    query = {"player_name": {"$regex": escaped_name, "$options": "i"}}
    return _find_many(Player, query)


def update_player(player_id: str, update_fields: dict):
    """
    Update fields on a player identified by player_id.
    Returns the number of modified documents (0 or 1).
    """
    return _update_one(Player, {"_id": player_id}, update_fields)


def delete_player(player_id: str):
    """
    Delete a player by player_id.
    Returns the number of deleted documents (0 or 1).
    """
    return _delete_one(Player, {"_id": player_id})


# ── Team ──────────────────────────────────────────────────────────────────────

def create_team(team: dict):
    """
    Insert a new team document.

    Expected fields (example):
        {
            "team_name": str,
            "sport": str,
            "members": [{"player_id": str, "role":str}, ...]
        }

    Returns the inserted _id, or None on failure.
    """
    team["_id"] = _create_id(Team)
    team["created_at"] = datetime.now(timezone.utc)
    return _insert_one(Team, team)


def get_team(team_id: str):
    """Fetch a team by team_id."""
    return _find_one(Team, {"_id": team_id})


def get_teams_by_query(query: dict):
    """Fetch all teams matching *query*. Pass None / {} to get every team."""
    return _find_many(Team, query)


def get_teams_by_name(name: str):
    """Fetch teams whose team_name matches *name* case-insensitively."""
    escaped_name = re.escape(name.strip())
    query = {"team_name": {"$regex": escaped_name, "$options": "i"}}
    return _find_many(Team, query)


def update_team(team_id: str, update_fields: dict):
    """
    Update fields on a team identified by team_id.
    Returns the number of modified documents (0 or 1).
    """
    return _update_one(Team, {"_id": team_id}, update_fields)


def delete_team(team_id: str):
    """
    Delete a team by team_id.
    Returns the number of deleted documents (0 or 1).
    """
    return _delete_one(Team, {"_id": team_id})


# ── Match ─────────────────────────────────────────────────────────────────────

def create_match(match: dict):
    """
    Insert a new match document.

    Expected fields (example):
        {   
            "match_no": int,
            "tournament_id": str,
            "entity1": {"team_id": str, "score":int},
            "entity2": {"team_id": str, "score":int},
            "scheduled_at": datetime,
            "status": str       # (not recommended to fill manually)"scheduled" | "ongoing" | "completed"
            "winner": int | none
        }

    Returns the inserted _id, or None on failure.
    """
    match["_id"] = _create_id(Match)
    match["created_at"] = datetime.now(timezone.utc)
    scheduled_at = match["scheduled_at"]
    if scheduled_at is not None:
        if scheduled_at.tzinfo is None:
            scheduled_at = scheduled_at.replace(tzinfo=timezone.utc)
        match["status"] = "scheduled" if scheduled_at > datetime.now(timezone.utc) else "ongoing"
    else:
        match["status"] = "scheduled" 

    return _insert_one(Match, match)


def get_match(match_id: str):
    """Fetch a match by match_id."""
    return _find_one(Match, {"_id": match_id})


def get_matches_by_query(query: dict):
    """Fetch all matches matching *query*. Pass None / {} to get every match."""
    return _find_many(Match, query)


def get_matches_by_tournament(tournament_id: str):
    """Fetch all matches belonging to a given tournament_id."""
    try:
        return list(Match.find({"tournament_id": tournament_id}).sort({"match_no":1}))
    except PyMongoError:
        logger.exception(f"get matches by tournament failed for {tournament_id}")
        return []


def update_match(match_id: str, update_fields: dict):
    """
    Update fields on a match identified by match_id.
    Returns the number of modified documents (0 or 1).
    """
    return _update_one(Match, {"_id": match_id}, update_fields)


def delete_match(match_id: str):
    """
    Delete a match by match_id.
    Returns the number of deleted documents (0 or 1).
    """
    return _delete_one(Match, {"_id": match_id})


# ── Tournament ────────────────────────────────────────────────────────────────

def create_tournament(tournament: dict):
    """
    Insert a new tournament document.

    Expected fields (example):
        {
            "tournament_name": str,
            "sports": str
            "start_date": datetime,
            "end_date": datetime,
            "location": str | dict
            "participants": [{"team_id": str, "playing": bool}, ...],
            "status": str       # "upcoming" | "ongoing" | "completed"
            "type": "knockout" | "cyclic"
        }

    Returns the inserted _id, or None on failure.
    """
    tournament["_id"] = _create_id(Tournament)
    tournament["created_at"] = datetime.now(timezone.utc)
    return _insert_one(Tournament, tournament)


def get_tournament(tournament_id: str):
    """Fetch a tournament by tournament_id."""
    return _find_one(Tournament, {"_id": tournament_id})


def get_tournaments_by_query(query: dict):
    """Fetch all tournaments matching *query*. Pass None / {} to get every tournament."""
    return _find_many(Tournament, query)


def get_tournaments_by_name(name: str):
    """Fetch tournaments whose tournament_name matches *name* case-insensitively."""
    escaped_name = re.escape(name.strip())
    query = {"tournament_name": {"$regex": escaped_name, "$options": "i"}}
    return _find_many(Tournament, query)


def update_tournament(tournament_id: str, update_fields: dict):
    """
    Update fields on a tournament identified by tournament_id.
    Returns the number of modified documents (0 or 1).
    """
    return _update_one(Tournament, {"_id": tournament_id}, update_fields)


def delete_tournament(tournament_id: str):
    """
    Delete a tournament by tournament_id.
    Returns the number of deleted documents (0 or 1).
    """
    return _delete_one(Tournament, {"_id": tournament_id})


def delete_tournament_cascade(tournament_id: str):
    """
    Delete a tournament AND all matches that belong to it.
    Returns a dict { "matches_deleted": int, "tournament_deleted": int }.
    """
    matches_deleted = _delete_many(Match, {"tournament_id": tournament_id})
    tournament_deleted = _delete_one(Tournament, {"_id": tournament_id})
    return {"matches_deleted": matches_deleted, "tournament_deleted": tournament_deleted}

# ── Search Features ───────────────────────────────────────────────────────────

def next_match_in_tournament(tournament_id: str):
    """
    Returns the next match in the tournament based on schedule
    """
    try:
        return Match.find_one({"tournament_id": tournament_id}, sort=[("scheduled_at", ASCENDING)])
    except PyMongoError:
        logger.error(f"next match failed on {tournament_id}",stack_info=True)
        return None

def get_completed_matches(tournament_id: str):
    """
    Returns the matches completed in the tournament
    """
    try:
        return Match.find({"tournament_id": tournament_id, "status":"completed"})
    except PyMongoError:
        logger.error(f"next match failed on {tournament_id}",stack_info=True)
        return None

def full_match_view(match_id: str):
    """
    Returns match with full team info of a match under field team1 and team2
    """
    pipeline = [
        {"$match": {"_id":match_id}},
        {"$lookup":{
          "from":"Team",
          "localField": "entity1.team_id",
          "foreignField": "_id",
          "as": "team1"
        }},
         {"$lookup":{
          "from":"Team",
          "localField": "entity2.team_id",
          "foreignField": "_id",
          "as": "team2"
        }},
        {"$unwind":"$team1"},{"$unwind":"$team2"}
    ]
    try:
        return list(Match.aggregate(pipeline))[0]
    except PyMongoError:
        logger.error(f"unable to view teams for match_id {match_id}",stack_info=True)
        return None

def full_team_view(tournament_id: str, playing_filter = 0, search_name: str = ""):
    """
    Returns the full info of each team playing in given tournament
    playing_filter = 1 => currently playing teams
                    -1 => not currently playing
                     0 => all                
    """
    filter = {
        -1: {"participants.playing":False},
        1: {"participants.playing":True},
        0: {}
    }
    pipeline = [
        {"$match":{"_id": tournament_id}},
        { "$unwind": "$participants"},
        {
            "$lookup":{
              "from": "Team",
              "localField": "participants.team_id",
              "foreignField": "_id",
              "as": "team"
            }
        },
        {"$unwind":"$team"},
        {"$match": filter.get(playing_filter,{})},
        {
          "$project":{
            "_id":0,
            "_id":"$team._id",
            "team_name": "$team.team_name",
            "sport": "$team.sport",
            "members":"$team.members",
            "playing": "$participants.playing"
          }
        }
    ]
    try:
        if search_name != "":
            escaped_name = re.escape(search_name.strip())
            name_match = {"$match":{"team_name": {"$regex": escaped_name, "$options": "i"}}}
            pipeline.append(name_match)
            

        return Tournament.aggregate(pipeline)
    except PyMongoError:
        logger.error(f"unable to view teams for tournament_id {tournament_id}",stack_info=True)
        return None


def inc_match_score(match_id: str, entity: int, inc_val = 1):
    """
    Increments the score of an entity(team) in a match by a given value
    entity = 1 | 2
    """
    if entity not in (1,2):
        logger.error("entity argument must be 1 or 2")
        return {"error":"entity argument must be 1 or 2"}
    try:
        result = Match.update_one({"_id":match_id}, {"$inc": {f"entity{entity}.score": inc_val } } )
        return {
            "matched_count": result.matched_count,
            "modified_count": result.modified_count,
            "acknowledged": result.acknowledged,
        }
    except PyMongoError:
        logger.error(f"unable to increment score for {match_id} and entity{entity}",stack_info=True)
        return None

def start_end_match(match_id: str):
    """
    Starts a match if it has not started, ends it if it is going on
    """
    find_query ={"_id": match_id}
    doc = _find_one(Match, find_query)
    if doc is None:
        return None
    new = {}
    if doc["status"] == "scheduled":
        new = {"status":"ongoing"}
    elif doc["status"] == "ongoing":
        new = {"status":"completed"}
    _update_one(Match,find_query,new)
    return new


# ── Match Fixtures─────────────────────────────────────────────────────────────

def generate_cyclic_matches(tournament_id: str):
    teams = list(full_team_view(tournament_id))
    if len(teams)<2: raise ValueError("At least 2 teams are required")

    match_docs = []

    for match_no,(team1,team2) in enumerate(combinations(teams,2), start=1):
        match_docs.append({
            "match_no": match_no,
            "tournament_id": tournament_id,
            "entity1": {
                "team_id": str(team1["_id"]),
                "score": 0
            },
            "entity2": {
                "team_id": str(team2["_id"]),
                "score": 0
            },
            "scheduled_at": None,
            "status": "scheduled",
            "winner": None
        })

    if match_docs:
        for d in match_docs:
            create_match(d)
    else: raise AssertionError("No matches were generated")

    return len(match_docs)

def generate_knockout_matches(tournament_id: str):
    teams = list(full_team_view(tournament_id))
    if len(teams)<2: raise ValueError("At least 2 teams are required")
    if len(teams) % 2 != 0: raise ValueError("Knockout should occur with even numbered teams")
    random.shuffle(teams)

    match_docs = []

    for match_no in range(len(teams) // 2):
        team1 = teams[2 * match_no]
        team2 = teams[2 * match_no + 1]

        match_docs.append({
            "match_no": match_no + 1,
            "tournament_id": tournament_id,
            "entity1": {
                "team_id": str(team1["_id"]),
                "score": 0
            },
            "entity2": {
                "team_id": str(team2["_id"]),
                "score": 0
            },
            "scheduled_at": None,
            "status": "scheduled",
            "winner": None
        })
        
    if match_docs:
        for d in match_docs:
            create_match(d)
    else: raise AssertionError("No matches were generated")

    return len(match_docs)

def generate_matches_for_tournament(tournament_id: str):
    doc = _find_one(Tournament,{"_id": tournament_id})
    if doc is None:
        raise ValueError("Tournament not found")

    generated = doc.get("generated", False)
    if generated: 
        raise ValueError("Cannot generate matches again, if matches have already been generated")

    if doc.get("type") is None: 
        raise ValueError("Type of tournament is not known")
    
    if doc["type"] == "cyclic":
        generated_matches = generate_cyclic_matches(tournament_id)
    elif doc["type"] == "knockout":
        generated_matches = generate_knockout_matches(tournament_id)
    else:
        raise ValueError("Not a valid tournament type")

    _update_one(Tournament, {"_id": tournament_id}, {"generated": True})
    return generated_matches
